from AM2315 import AM2315

sensor=AM2315()
print(sensor.values())

